// Importar dependencias
const axios = require('axios');
const xml2js = require('xml2js'); // Para parsear XML a JSON
const dotenv = require('dotenv');

// Cargar variables de entorno desde el archivo .env
dotenv.config();

// Función para obtener la imagen del día (APOD) en JSON
const getAPOD = async () => {
    try {
        // Obtener la API key desde las variables de entorno
        const apiKey = process.env.NASA_API_KEY;

        // Verificar si la API key está configurada
        if (!apiKey) {
            throw new Error('NASA_API_KEY no está configurada en el archivo .env');
        }

        // URL de la NASA API APOD
        const url = `https://api.nasa.gov/planetary/apod?api_key=${apiKey}`;

        // Hacer la solicitud a la API usando axios
        const response = await axios.get(url);

        // Devolver los datos obtenidos
        return response.data;
    } catch (error) {
        console.error('Error haciendo la petición a APOD:', error.message);
        throw error;
    }
};

// Función para obtener noticias de la NASA en XML (RSS Feed)
const getNASANews = async () => {
    try {
        // URL del feed RSS de noticias de la NASA
        const url = 'https://www.nasa.gov/rss/dyn/breaking_news.rss';

        // Hacer la solicitud a la API usando axios
        const response = await axios.get(url);

        // Parsear XML a JSON
        const parser = new xml2js.Parser();
        const result = await parser.parseStringPromise(response.data);

        // Devolver los datos obtenidos
        return result;
    } catch (error) {
        console.error('Error haciendo la petición a NASA News:', error.message);
        throw error;
    }
};

// Función para obtener datos de exoplanetas
const getExoplanets = async () => {
    try {
        const url = 'https://exoplanetarchive.ipac.caltech.edu/cgi-bin/nstedAPI/nph-nstedAPI?table=exoplanets&format=json';
        const response = await axios.get(url);

        // Verificar si la respuesta es un array
        if (Array.isArray(response.data)) {
            return response.data; // Devolver los datos si es un array
        } else if (response.data && typeof response.data === 'object') {
            // Si es un objeto, intentar extraer los datos
            if (response.data.data) {
                return response.data.data; // Algunas APIs devuelven los datos en una propiedad "data"
            } else {
                return Object.values(response.data); // Convertir el objeto en un array
            }
        } else {
            throw new Error('La respuesta de la API de exoplanetas no es un array ni un objeto.');
        }
    } catch (error) {
        console.error('Error obteniendo datos de exoplanetas:', error.message);
        throw error;
    }
};

// Función para obtener información sobre el clima espacial y eventos solares
const getSpaceWeather = async () => {
    try {
        const apiKey = process.env.NASA_API_KEY;

        // Verificar si la API key está configurada
        if (!apiKey) {
            throw new Error('NASA_API_KEY no está configurada en el archivo .env');
        }

        // URL de la NASA API para clima espacial
        const url = `https://api.nasa.gov/DONKI/notifications?api_key=${apiKey}`;

        // Hacer la solicitud a la API usando axios
        const response = await axios.get(url);

        // Devolver los datos obtenidos
        return response.data;
    } catch (error) {
        console.error('Error obteniendo datos del clima espacial:', error.message);
        throw error;
    }
};

// Función para obtener fotos de la Tierra (EPIC)
const getEarthPhotos = async () => {
    try {
        const apiKey = process.env.NASA_API_KEY;

        // Verificar si la API key está configurada
        if (!apiKey) {
            throw new Error('NASA_API_KEY no está configurada en el archivo .env');
        }

        // URL de la NASA API EPIC
        const url = `https://api.nasa.gov/EPIC/api/natural/images?api_key=${apiKey}`;

        // Hacer la solicitud a la API usando axios
        const response = await axios.get(url);

        // Devolver los datos obtenidos
        return response.data;
    } catch (error) {
        console.error('Error obteniendo fotos de la Tierra:', error.message);
        throw error;
    }
};

// Función principal para ejecutar el script
const main = async () => {
    try {
        // Obtener los datos de la APOD (JSON)
        const apodData = await getAPOD();
        console.log('Datos de la APOD (JSON):');
        console.log('-----------------------');
        console.log(`Título: ${apodData.title}`);
        console.log(`Fecha: ${apodData.date}`);
        console.log(`Explicación: ${apodData.explanation}`);
        console.log(`URL de la imagen: ${apodData.url}`);
        if (apodData.hdurl) {
            console.log(`URL de la imagen en alta calidad: ${apodData.hdurl}`);
        }
        console.log(`Tipo de medio: ${apodData.media_type}`);
        console.log('\n');

        // Obtener las noticias de la NASA (XML)
        const newsData = await getNASANews();
        console.log('Noticias de la NASA (XML parseado a JSON):');
        console.log('-----------------------------------------');
        const newsItems = newsData.rss.channel[0].item;
        newsItems.forEach((item, index) => {
            console.log(`Noticia ${index + 1}:`);
            console.log(`- Título: ${item.title[0]}`);
            console.log(`- Enlace: ${item.link[0]}`);
            console.log(`- Descripción: ${item.description[0]}`);
            console.log('\n');
        });

        // Obtener datos de exoplanetas
        const exoplanetsData = await getExoplanets();
        console.log('Datos de exoplanetas descubiertos:');
        console.log('----------------------------------');
        if (Array.isArray(exoplanetsData)) {
            exoplanetsData.slice(0, 5).forEach((exoplanet, index) => {
                console.log(`Exoplaneta ${index + 1}:`);
                console.log(`- Nombre: ${exoplanet.pl_name}`);
                console.log(`- Periodo orbital: ${exoplanet.pl_orbper} días`);
                console.log(`- Masa: ${exoplanet.pl_bmassj} veces la masa de Júpiter`);
                console.log('\n');
            });
        } else {
            console.log('La respuesta de la API de exoplanetas no es un array.');
        }

        // Obtener información sobre el clima espacial y eventos solares
        const spaceWeatherData = await getSpaceWeather();
        console.log('Clima espacial y eventos solares:');
        console.log('---------------------------------');
        spaceWeatherData.forEach((event, index) => {
            console.log(`Evento ${index + 1}:`);
            console.log(`- Tipo: ${event.messageType}`);
            console.log(`- Fecha: ${event.messageIssueTime}`);
            console.log(`- Descripción: ${event.messageBody}`);
            console.log('\n');
        });

        // Obtener fotos de la Tierra (EPIC)
        const earthPhotosData = await getEarthPhotos();
        console.log('Fotos de la Tierra (EPIC):');
        console.log('--------------------------');
        earthPhotosData.slice(0, 5).forEach((photo, index) => {
            console.log(`Foto ${index + 1}:`);
            console.log(`- Fecha: ${photo.date}`);
            console.log(`- Imagen: https://epic.gsfc.nasa.gov/archive/natural/${photo.date.split(' ')[0].replace(/-/g, '/')}/png/${photo.image}.png`);
            console.log('\n');
        });
    } catch (error) {
        console.error('Error en el script:', error.message);
    }
};

// Ejecutar la función principal
main();