// Importar dependencias
const axios = require('axios');
const xml2js = require('xml2js'); // Para parsear XML a JSON
const dotenv = require('dotenv');

// Cargar variables de entorno desde el archivo .env
dotenv.config();

// Función para obtener la imagen del día (APOD) en JSON
const getAPOD = async () => {
    try {
        // Obtener la API key desde las variables de entorno
        const apiKey = process.env.NASA_API_KEY;

        // Verificar si la API key está configurada
        if (!apiKey) {
            throw new Error('NASA_API_KEY no está configurada en el archivo .env');
        }

        // URL de la NASA API APOD
        const url = `https://api.nasa.gov/planetary/apod?api_key=${apiKey}`;

        // Hacer la solicitud a la API usando axios
        const response = await axios.get(url);

        // Devolver los datos obtenidos
        return response.data;
    } catch (error) {
        console.error('Error haciendo la petición a APOD:', error.message);
        throw error;
    }
};

// Función para obtener noticias de la NASA en XML (RSS Feed)
const getNASANews = async () => {
    try {
        // URL del feed RSS de noticias de la NASA
        const url = 'https://www.nasa.gov/rss/dyn/breaking_news.rss';

        // Hacer la solicitud a la API usando axios
        const response = await axios.get(url);

        // Parsear XML a JSON
        const parser = new xml2js.Parser();
        const result = await parser.parseStringPromise(response.data);

        // Devolver los datos obtenidos
        return result;
    } catch (error) {
        console.error('Error haciendo la petición a NASA News:', error.message);
        throw error;
    }
};

// Función principal para ejecutar el script
const main = async () => {
    try {
        // Obtener los datos de la APOD (JSON)
        const apodData = await getAPOD();
        console.log('Datos de la APOD (JSON):');
        console.log('-----------------------');
        console.log(`Título: ${apodData.title}`);
        console.log(`Fecha: ${apodData.date}`);
        console.log(`Explicación: ${apodData.explanation}`);
        console.log(`URL de la imagen: ${apodData.url}`);
        if (apodData.hdurl) {
            console.log(`URL de la imagen en alta calidad: ${apodData.hdurl}`);
        }
        console.log(`Tipo de medio: ${apodData.media_type}`);
        console.log('\n');

        // Obtener las noticias de la NASA (XML)
        const newsData = await getNASANews();
        console.log('Noticias de la NASA (XML parseado a JSON):');
        console.log('-----------------------------------------');
        const newsItems = newsData.rss.channel[0].item;
        newsItems.forEach((item, index) => {
            console.log(`Noticia ${index + 1}:`);
            console.log(`- Título: ${item.title[0]}`);
            console.log(`- Enlace: ${item.link[0]}`);
            console.log(`- Descripción: ${item.description[0]}`);
            console.log('\n');
        });
    } catch (error) {
        console.error('Error en el script:', error.message);
    }
};

// Ejecutar la función principal
main();